<?php 

const HOST = "api2.megaapi.com.br";
const INSTANCE = "megaapi-M4lJe6NiI1ZEJfDQCY4BMIy9y6";
const TOKEN = "M4lJe6NiI1ZEJfDQCY4BMIy9y6";