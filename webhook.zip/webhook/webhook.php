<?php

include "config.php";

/**
 * Recebo o json da api
 */
$data = file_get_contents('php://input');

/**
 * Transformo o json em array
 */
$array = json_decode($data, true)["json"];
// debugArray($array);
// echo "Aqui é o php --------------------------------------------";
// exit;


$fromMe  = $array["key"]["fromMe"];//Mensagem recebida ou enviada (true -> Enviada / false -> Recebida)
$type    = $array["messageType"];//Tipo de mensagem recebida

/**
 * Validação se é uma mensagem recebida ou enviada
 */
if( !$fromMe ){

    //verificação do if de message.ack
    if( $type != "message.ack" ){
     
        /**Pego as informações do array - MSG botoes*/
        $instance       = $array["instance_key"];//Instancia
        $phoneConect    = $array["jid"];//Telefone conectado na api
        $chatid         = $array["key"]["remoteJid"];//Contato cliente
        $idMessage      = $array["key"]["id"];//ID da mensagem
        $time           = $array["messageTimestamp"];//Hora e data que foi enviada
        $name           = $array["pushName"];//Nome do contato
        $participant    = $array["key"]["participant"] ?? "";//Participante que enviou a mensagem no grupo
        $time           = $array["messageTimestamp"];//Hora e data que foi enviada
        $message        = empty($array["message"]["conversation"]) ? "" : $array["message"]["conversation"];//Mensagem do chat
        $idBtn          = empty($array["message"]["buttonsResponseMessage"]["selectedButtonId"]) ? "" : $array["message"]["buttonsResponseMessage"]["selectedButtonId"];//ID dos botoes
        $textBtn        = empty($array["message"]["buttonsResponseMessage"]["selectedDisplayText"]) ? "" : $array["message"]["buttonsResponseMessage"]["selectedDisplayText"];//Texto dos Botoes
        $titleList      = empty($array["message"]["listResponseMessage"]["tile"]) ? "" : $array["message"]["listResponseMessage"]["tile"];//Titulo da lista
        $idList         = empty($array["message"]["listResponseMessage"]["singleSelectReply"]["selectedRowId"]) ? "" : $array["message"]["listResponseMessage"]["singleSelectReply"]["selectedRowId"];//Id da lista


        //bot
        if( $message == "#start" ){

            $buttons = array (
                array("title" => "Sim"),
                array("title" => "Não"),
            );
            echo sendBuntton($chatid, "Ola seja bem vindo, para iniciar o atendimento selecione uma das opções abaixo!", $buttons, "Selecione uma das opções");
            exit;

        }else if( $textBtn == "Sim" ){

            sendList($chatid);
            exit;

        }else if( $textBtn == "Não" ){

            echo templateMesage($chatid);
            exit;

        }else if( $message == "#sair" ){

            $buttons = array (
                array("title" => "Menu Inicial"),
            );
            echo sendBuntton($chatid, "Ok volte sempre", $buttons, "Selecione uma das opções");
            exit;


        }

  
    
        exit;

    }


}else{

    /**
     * Retornos dos status das mensagens enviadas
     */
    switch ($type) {

        case 'message.ack':
             /**Pego as informações do array - Status de vizualização da mensagem*/
             $instance      = $array["instance_key"];//Instancia
             $chatid        = $array["key"]["remoteJid"];//Contato cliente
             $idMessage     = $array["key"]["id"];//ID da mensagem
             $status        = replaceAck($array["update"]["status"]);
            break;
        
    }

}


/**
 * Função para debugar array com print_r;
 *
 * @param [array] $array
 */
function debugArray($array){

    echo "<pre>";
    print_r($array);
}

/**
 * Função responsavel por fazer o tratamento do status das mensagens 
 *
 * @param [string] $status
 * @return string $status
 */
function replaceAck($status){

    /**
     * Fazemos o tratamento do status
     */
    switch ($status) {
        case '2':
            $status = "Send";
            return $status;
            break;

        case '3':
            $status = "Delivered";
            return $status;
            break;

        case '4':
            $status = "Viewd";
            return $status;
            break;
        
    }

}



function sendBuntton($contact, $message, $buttons, $footer){

    try {

        $data = array(

            "messageData" => array (

                "to"         => $contact,
                "text"       => $message,
                "buttons"    => $buttons,
                "footerText" => $footer

            )

        );

        
        $data = json_encode($data);
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://'.HOST.'/rest/sendMessage/'.INSTANCE.'/buttonMessage',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$data,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer '.TOKEN
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;


    } catch (\Exception $th) {
        return false;
    }

}

function sendList($contact){

    $curl = curl_init();

    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://'.HOST.'/rest/sendMessage/'.INSTANCE.'/listMessage',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>'{
        "messageData": {
            "to": "'.$contact.'",
            "buttonText": "Clique Aqui",
            "text": "Selecione uma forma de pagamento",
            "title": "PAGAMENTOS",
            "description": "lista de formatos de pagamentos",
            "sections": [
                {
                    "title": "PIX",
                    "rows": [
                        {
                            "title": "PIX",
                            "description": "Pagamento via pix",
                            "rowId": "001"
                        }
                    ]
                },
                {
                    "title": "Cartão de Crédito 💳",
                    "rows": [
                        {
                            "title": "Cartão de Crédito",
                            "description": "Pagamento via Cartão de Crédito",
                            "rowId": "002"
                        }
                    ]
                }
            ],
            "listType": 0
        }
    }',
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'Authorization: Bearer '.TOKEN
    ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    return $response;
}


function templateMesage($contact){

    $curl = curl_init();

    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://'.HOST.'/rest/sendMessage/'.INSTANCE.'/templateMessage',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>'{
        "messageData": {
            "to": "'.$contact.'",
            "text": "Exemplo de templateMessage",
            "buttons": [
                {
                    "type": "replyButton",
                    "title": "Menu Inicial"
                },
                {
                    "type": "replyButton",
                    "title": "Sair"
                },
                {
                    "type": "urlButton",
                    "title": "Site Google",
                    "payload": "https://google.com"
                },
                {
                    "type": "urlButton",
                    "title": "Ligar Megaapi",
                    "payload": "https://megaapi.io"
                }
            ],
            "footerText": "Selecione uma das opções"
        }
    }',
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'Authorization: Bearer '.TOKEN
    ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    return $response;

}